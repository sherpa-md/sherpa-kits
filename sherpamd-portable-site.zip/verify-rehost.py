#!/usr/bin/env python3
"""Verify that a SherpaMD mirror matches the canonical portable snapshot."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import re
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath


DEFAULT_CANONICAL_INDEX = (
    "https://raw.githubusercontent.com/sherpa-md/sherpa-kits/portable-site/index.json"
)
EXPECTED_REPOSITORY = "sherpa-md/sherpa-kits"
COMMIT_RE = re.compile(r"^[0-9a-f]{40}$")
HASH_RE = re.compile(r"^[0-9a-f]{64}$")
CHECKSUM_EXCLUSIONS = {".nojekyll", "SHA256SUMS", "sherpamd-portable-site.zip"}
REQUIRED_FILES = (
    "index.html",
    "index.json",
    "llms.txt",
    "ratings.json",
    "projects.json",
    "projects/index.html",
    "robots.txt",
    "sitemap.xml",
    "SHA256SUMS",
    "LICENSE",
    "CONTRIBUTING.md",
    "SECURITY.md",
    "REHOSTING.md",
    "update-rehost.py",
    "verify-rehost.py",
    "assets/site.css",
    "assets/site.js",
    "all-sherpas.zip",
    "all-ai-handoffs.zip",
    "sherpamd-portable-site.zip",
)
MAX_DOWNLOAD_BYTES = 100 * 1024 * 1024
EXPECTED_DOWNLOADS = [
    {
        "id": "source-markdown",
        "title": "All Sherpa Markdown files",
        "url": "/all-sherpas.zip",
        "media_type": "application/zip",
        "contents": "Exact public .sherpa.md source files with repository paths preserved.",
    },
    {
        "id": "ai-handoffs",
        "title": "All AI handoffs",
        "url": "/all-ai-handoffs.zip",
        "media_type": "application/zip",
        "contents": "One generated, independently checksummed AI handoff per public Sherpa.",
    },
    {
        "id": "portable-site",
        "title": "Complete rehostable site",
        "url": "/sherpamd-portable-site.zip",
        "media_type": "application/zip",
        "contents": "The complete static catalog, downloads, policies, and rehosting tools.",
    },
    {
        "id": "checksums",
        "title": "SHA-256 checksums",
        "url": "/SHA256SUMS",
        "media_type": "text/plain",
        "contents": "SHA-256 inventory for the generated public files.",
    },
]


class VerificationError(RuntimeError):
    """Raised when a mirror is incomplete, altered, or stale."""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Verify a deployed or extracted SherpaMD portable site."
    )
    target = parser.add_mutually_exclusive_group(required=True)
    target.add_argument(
        "--base-url", help="HTTPS origin to verify, for example https://sherpamd.org"
    )
    target.add_argument(
        "--site-dir", type=Path, help="Extracted portable-site directory to verify offline"
    )
    parser.add_argument(
        "--canonical-index",
        default=DEFAULT_CANONICAL_INDEX,
        help="Canonical index.json URL or local file (default: portable-site branch)",
    )
    parser.add_argument(
        "--canonical-checksums",
        help="Canonical SHA256SUMS URL or local file (default: beside canonical index.json)",
    )
    parser.add_argument(
        "--expect-source-commit",
        help="Also require this lowercase 40-character source commit",
    )
    parser.add_argument(
        "--allow-http",
        action="store_true",
        help="Permit plain HTTP for a private development mirror",
    )
    return parser.parse_args()


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_relative(path: str) -> bool:
    candidate = PurePosixPath(path)
    return (
        bool(path)
        and not candidate.is_absolute()
        and ".." not in candidate.parts
        and "\\" not in path
    )


def read_url(url: str) -> bytes:
    request = urllib.request.Request(
        url, headers={"User-Agent": "SherpaMD-Rehost-Verifier/1"}
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            data = response.read(MAX_DOWNLOAD_BYTES + 1)
    except (OSError, urllib.error.HTTPError) as exc:
        raise VerificationError(f"could not fetch {url}: {exc}") from exc
    if len(data) > MAX_DOWNLOAD_BYTES:
        raise VerificationError(f"response exceeds 100 MiB safety limit: {url}")
    return data


def read_locator(locator: str, label: str) -> bytes:
    parsed = urllib.parse.urlparse(locator)
    if parsed.scheme in {"http", "https"}:
        return read_url(locator)
    if parsed.scheme:
        raise VerificationError(f"unsupported {label} scheme: {parsed.scheme}")
    path = Path(locator).expanduser()
    try:
        return path.read_bytes()
    except OSError as exc:
        raise VerificationError(f"could not read {label} {path}: {exc}") from exc


def sibling_locator(locator: str, filename: str) -> str:
    parsed = urllib.parse.urlparse(locator)
    if parsed.scheme in {"http", "https"}:
        return urllib.parse.urljoin(locator, filename)
    if parsed.scheme:
        raise VerificationError(f"unsupported canonical index scheme: {parsed.scheme}")
    return str(Path(locator).expanduser().parent / filename)


def parse_checksums(data: bytes, label: str) -> dict[str, str]:
    try:
        lines = data.decode("utf-8").splitlines()
    except UnicodeDecodeError as exc:
        raise VerificationError(f"{label} is not valid UTF-8") from exc
    checksums: dict[str, str] = {}
    for line in lines:
        match = re.fullmatch(r"([0-9a-f]{64})  (.+)", line)
        if not match:
            raise VerificationError(f"{label} contains an invalid entry")
        digest, relative = match.groups()
        if (
            not safe_relative(relative)
            or relative in CHECKSUM_EXCLUSIONS
            or not HASH_RE.fullmatch(digest)
        ):
            raise VerificationError(f"{label} contains an unsafe entry: {relative!r}")
        if relative in checksums:
            raise VerificationError(f"{label} contains a duplicate entry: {relative}")
        checksums[relative] = digest
    if not checksums:
        raise VerificationError(f"{label} must contain at least one file")
    return checksums


class SiteReader:
    def __init__(self, base_url: str | None, site_dir: Path | None, allow_http: bool):
        self.base_url = base_url.rstrip("/") + "/" if base_url else None
        self.site_dir = site_dir.expanduser().resolve() if site_dir else None
        self.cache: dict[str, bytes] = {}
        if self.base_url:
            parsed = urllib.parse.urlparse(self.base_url)
            if parsed.scheme not in {"http", "https"} or not parsed.netloc:
                raise VerificationError("--base-url must be an absolute HTTP(S) URL")
            if parsed.scheme != "https" and not allow_http:
                raise VerificationError("public mirrors must use HTTPS (or pass --allow-http)")
        elif not self.site_dir or not self.site_dir.is_dir():
            raise VerificationError("--site-dir must identify an extracted site directory")

    def read(self, relative: str) -> bytes:
        if not safe_relative(relative):
            raise VerificationError(f"unsafe site path: {relative!r}")
        if relative in self.cache:
            return self.cache[relative]
        if self.base_url:
            data = read_url(urllib.parse.urljoin(self.base_url, relative))
        else:
            assert self.site_dir is not None
            path = self.site_dir.joinpath(*PurePosixPath(relative).parts)
            try:
                data = path.read_bytes()
            except OSError as exc:
                raise VerificationError(f"could not read {relative}: {exc}") from exc
        self.cache[relative] = data
        return data


def parse_manifest(data: bytes, label: str) -> dict:
    try:
        manifest = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise VerificationError(f"{label} is not valid UTF-8 JSON") from exc
    if not isinstance(manifest, dict):
        raise VerificationError(f"{label} must be a JSON object")
    if manifest.get("schema_version") != "1":
        raise VerificationError(f"{label} uses an unsupported schema")
    if manifest.get("source_repository") != EXPECTED_REPOSITORY:
        raise VerificationError(f"{label} does not identify the canonical repository")
    if manifest.get("downloads") != EXPECTED_DOWNLOADS:
        raise VerificationError(f"{label} bulk download inventory is missing or altered")
    commit = manifest.get("source_commit")
    if not isinstance(commit, str) or not COMMIT_RE.fullmatch(commit):
        raise VerificationError(f"{label} has an invalid source_commit")
    items = manifest.get("items")
    if not isinstance(items, list) or not items or manifest.get("count") != len(items):
        raise VerificationError(f"{label} count does not match its non-empty items list")
    return manifest


def validate_items(manifest: dict) -> tuple[list[dict], list[str], set[str]]:
    items = manifest["items"]
    identities: set[tuple[str, str]] = set()
    source_paths: list[str] = []
    required_routes = set(REQUIRED_FILES)
    for item in items:
        if not isinstance(item, dict):
            raise VerificationError("index.json contains a non-object item")
        kind, item_id = item.get("kind"), item.get("id")
        if not isinstance(kind, str) or not kind or not isinstance(item_id, str) or not item_id:
            raise VerificationError("index.json contains a missing type-qualified ID")
        identity = (kind, item_id)
        if identity in identities:
            raise VerificationError(f"duplicate type-qualified ID: {kind}:{item_id}")
        identities.add(identity)

        source_path = item.get("source_path")
        raw_url = item.get("raw_url")
        route = item.get("route")
        expected_hash = item.get("sha256")
        ai_handoff_url = item.get("ai_handoff_url")
        ai_handoff_hash = item.get("ai_handoff_sha256")
        if not isinstance(source_path, str) or not safe_relative(source_path):
            raise VerificationError(f"unsafe source_path for {kind}:{item_id}")
        if raw_url != f"/raw/{source_path}":
            raise VerificationError(f"raw URL does not preserve source_path for {kind}:{item_id}")
        if not isinstance(route, str) or not route.startswith("/") or ".." in route:
            raise VerificationError(f"unsafe route for {kind}:{item_id}")
        if not isinstance(expected_hash, str) or not HASH_RE.fullmatch(expected_hash):
            raise VerificationError(f"invalid SHA-256 for {kind}:{item_id}")
        if ai_handoff_url != route + "ai-handoff.txt":
            raise VerificationError(f"unstable AI handoff URL for {kind}:{item_id}")
        if not isinstance(ai_handoff_hash, str) or not HASH_RE.fullmatch(ai_handoff_hash):
            raise VerificationError(f"invalid AI handoff SHA-256 for {kind}:{item_id}")
        source_paths.append(source_path)
        required_routes.add(raw_url.lstrip("/"))
        required_routes.add(route.strip("/") + "/index.html")
        required_routes.add(ai_handoff_url.lstrip("/"))
    return items, source_paths, required_routes


def verify_archive(data: bytes, items: list[dict], source_paths: list[str]) -> None:
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            if sorted(archive.namelist()) != sorted(source_paths):
                raise VerificationError("all-sherpas.zip inventory does not match index.json")
            for item in items:
                if sha256(archive.read(item["source_path"])) != item["sha256"]:
                    raise VerificationError(
                        f"all-sherpas.zip hash mismatch for {item['source_path']}"
                    )
    except zipfile.BadZipFile as exc:
        raise VerificationError("all-sherpas.zip is not a valid ZIP archive") from exc


def verify_handoff_archive(data: bytes, items: list[dict]) -> None:
    expected_paths = sorted(item["ai_handoff_url"].lstrip("/") for item in items)
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            if sorted(archive.namelist()) != expected_paths:
                raise VerificationError(
                    "all-ai-handoffs.zip inventory does not match index.json"
                )
            for item in items:
                handoff_path = item["ai_handoff_url"].lstrip("/")
                if sha256(archive.read(handoff_path)) != item["ai_handoff_sha256"]:
                    raise VerificationError(
                        f"all-ai-handoffs.zip hash mismatch for {item['source_path']}"
                    )
    except zipfile.BadZipFile as exc:
        raise VerificationError("all-ai-handoffs.zip is not a valid ZIP archive") from exc


def verify_site_archive(data: bytes, expected_files: set[str]) -> None:
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            names = set(archive.namelist())
    except zipfile.BadZipFile as exc:
        raise VerificationError("sherpamd-portable-site.zip is not a valid ZIP archive") from exc
    expected = expected_files | {"SHA256SUMS"}
    if names != expected:
        missing = sorted(expected - names)
        extra = sorted(names - expected)
        detail = f"missing {missing[0]}" if missing else f"unexpected {extra[0]}"
        raise VerificationError(
            f"portable site ZIP inventory differs from the snapshot: {detail}"
        )


def main() -> int:
    args = parse_args()
    if args.expect_source_commit and not COMMIT_RE.fullmatch(args.expect_source_commit):
        raise VerificationError(
            "--expect-source-commit must be a lowercase 40-character SHA"
        )

    canonical = parse_manifest(
        read_locator(args.canonical_index, "canonical index.json"),
        "canonical index.json",
    )
    canonical_checksums_locator = args.canonical_checksums or sibling_locator(
        args.canonical_index, "SHA256SUMS"
    )
    canonical_checksums_data = read_locator(
        canonical_checksums_locator, "canonical SHA256SUMS"
    )
    canonical_checksums = parse_checksums(
        canonical_checksums_data, "canonical SHA256SUMS"
    )
    reader = SiteReader(args.base_url, args.site_dir, args.allow_http)
    deployed = parse_manifest(reader.read("index.json"), "deployed index.json")
    if deployed != canonical:
        if deployed.get("source_commit") != canonical.get("source_commit"):
            raise VerificationError(
                "mirror is stale: deployed source commit "
                f"{deployed.get('source_commit')} != canonical {canonical.get('source_commit')}"
            )
        raise VerificationError("deployed index.json differs from the canonical snapshot")
    commit = deployed["source_commit"]
    if args.expect_source_commit and commit != args.expect_source_commit:
        raise VerificationError(
            f"expected source commit {args.expect_source_commit}, received {commit}"
        )

    items, source_paths, required_routes = validate_items(deployed)
    deployed_checksums_data = reader.read("SHA256SUMS")
    if deployed_checksums_data != canonical_checksums_data:
        raise VerificationError("deployed SHA256SUMS differs from the canonical snapshot")
    deployed_checksums = parse_checksums(deployed_checksums_data, "deployed SHA256SUMS")
    if deployed_checksums != canonical_checksums:
        raise VerificationError("deployed checksum inventory differs from the canonical snapshot")
    missing_checksums = (required_routes - CHECKSUM_EXCLUSIONS) - set(deployed_checksums)
    if missing_checksums:
        raise VerificationError(
            f"SHA256SUMS is missing required file {sorted(missing_checksums)[0]}"
        )
    for relative in sorted(required_routes):
        data = reader.read(relative)
        if not data:
            raise VerificationError(f"mirror returned an empty file: {relative}")
    for relative, expected_hash in deployed_checksums.items():
        if sha256(reader.read(relative)) != expected_hash:
            raise VerificationError(f"SHA256SUMS mismatch for {relative}")
    for item in items:
        raw = reader.read(item["raw_url"].lstrip("/"))
        if sha256(raw) != item["sha256"]:
            raise VerificationError(f"raw file hash mismatch for {item['source_path']}")
        handoff_path = item["ai_handoff_url"].lstrip("/")
        if deployed_checksums.get(handoff_path) != item["ai_handoff_sha256"]:
            raise VerificationError(
                f"AI handoff checksum mismatch for {item['source_path']}"
            )

    verify_archive(reader.read("all-sherpas.zip"), items, source_paths)
    verify_handoff_archive(reader.read("all-ai-handoffs.zip"), items)
    verify_site_archive(
        reader.read("sherpamd-portable-site.zip"), set(deployed_checksums)
    )

    print(f"[PASS] mirror matches canonical source commit {commit}")
    print(f"[PASS] {len(items)}/{len(items)} Sherpa identities, routes, and SHA-256 hashes")
    print(f"[PASS] {len(deployed_checksums)} generated files match canonical SHA256SUMS")
    print("[PASS] required assets and all three download archives are complete")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except VerificationError as exc:
        print(f"ERROR: {exc}", file=__import__("sys").stderr)
        raise SystemExit(1)
